import java.util.Scanner;
import java.util.LinkedList;


public class TestCollection {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		LinkedList<Integer> arr = new LinkedList<Integer>();
		CollectionInfo cinfo = new CollectionInfo();	
		int ch = 0;

		do {

			System.out.println("1 - To Create the Linked list\n2 - To Check if the element is present in the linked list or not\n3 - To Remove the Element from Linked list\n4 - To check the size of the linked list\n5 - To insert the number into the linked list\n6 - To find the highest element in the list\n7 - To display the linked list\n8 - Sorting the linked list\n9 - deleting an index from the linked list");
			System.out.println("Enter your choice : ");
			ch = sc.nextInt();

			switch(ch) {	

			case 1 :
				arr = cinfo.Create();				
				break;

			case 2 :
				CollectionInfo.searchElement(ch, arr);
				break;

			case 3 :
				cinfo.RemovedElement(ch);
				break;

			case 4 :
				CollectionInfo.sizeList(arr);
				break;

			case 5 :
				cinfo.insertNumber(ch);
				break;

			case 6 :
				cinfo.highElement(ch);
				break;

			case 7 :
				CollectionInfo.displaylist(arr);
				break;

			case 8 :
				CollectionInfo.sorting(arr);
				break;

			case 9 :
				CollectionInfo.deleteList(arr);
				break;

			default :
				System.out.println("Invalid choice...");
				break;

			}

			System.out.println("Do you want to continue? press 1 (Main Menu)");
			ch = sc.nextInt();

		}while(ch == 1);
		System.out.println("Thank you...");

	}
}
