import java.util.Scanner;
import java.util.Collections;
import java.util.LinkedList;

public class CollectionInfo {

	Scanner sc = new Scanner(System.in);
	LinkedList<Integer> list = new LinkedList<Integer>();

	public LinkedList<Integer> Create() {  // creating the linked list
		int ch = 0;

		System.out.println("To enter the elements in the linked list...");
		do {
			System.out.println("Enter the integer : ");
			int n = sc.nextInt();
			list.add(n);

			System.out.println("Do you want to continue ? press 1 (create list)");
			ch = sc.nextInt();

		}while(ch == 1);

		return list;
	}


	public static void displaylist(LinkedList<Integer> list) {  // to display the linked list

		System.out.println("Linked List : " + list);
	}


	public static void searchElement(int x, LinkedList<Integer> list) { // to check if the element is present or not 
		Scanner st = new Scanner(System.in);

		System.out.println("Enter the element do you want to search : ");
		x = st.nextInt();

		if(list.contains(x)) {
			System.out.println("Number found at Index : " + list.indexOf(x));
		}
	}


	public LinkedList<Integer> RemovedElement(int m) { // to display the removed element at nth index

		System.out.println("Enter the position do you want to remove the number : ");
		m = sc.nextInt();
		System.out.println(list.remove(m));
		return list;
	}


	public static void sizeList(LinkedList<Integer> list) {  // to check the size of the linked list

		System.out.println("Size of Linked List : " + list.size());
	}


	public LinkedList<Integer> insertNumber(int n1) {  // To insert the number into the linked list

		System.out.println("Insert the number n1 : ");
		n1 = sc.nextInt();

		System.out.println(list.add(n1));
		System.out.println("Element added successfully! new List is : " + list);
		return list;	    

	}

	public LinkedList<Integer> highElement(int n) {  // to find the highest number in the list
		int max = 0;

		if(list.get(list.size() - 1) > max) {
			max = list.get(list.size() - 1);
		}

		System.out.println("The highest Element is : " + max);
		return list;

	}


	public static LinkedList<Integer> sorting(LinkedList<Integer> list) {  // sorting the linked list

		Collections.sort(list);
		System.out.println("Sorted List : " + list);

		return list;		
	}


	public static void deleteList(LinkedList<Integer> list) {  //deleting an element from the linked list 
		Scanner s = new Scanner(System.in);

		System.out.println("Enter the number to be deleted : ");
		int y = s.nextInt();

		if(list.contains(y)) {
			list.remove(list.indexOf(y));
			System.out.println("Element deleted ! ");
		}
		else {
			System.out.println("Element not found...");
		}
	}
}
