import java.util.Scanner;
import java.util.InputMismatchException;
import java.util.LinkedList;
import java.util.List;

public class AccountMain extends Exception {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		AccountInfo ainfo = new AccountInfo();
		List<Account> listAcc = new LinkedList<Account>();
		int ch = 0;

		do {
			System.out.println("1 - Create Account\n2 - Display Account\n3 - Search Account\n4 - Sort Account\n5 - Update Account\n6 - Delete Account");

			try {
				System.out.println("Enter your choice : ");
				ch = sc.nextInt();
			}
			catch(InputMismatchException ex1) {
				System.err.println("Exception is : " + ex1);
				System.out.println("Please Enter Integer values only...");
			}

			switch(ch) {

			case 1 :
				try {
					listAcc = ainfo.createAccount();
				} catch (BalanceException e) {
					e.printStackTrace();
				}
				break;

			case 2 :
				AccountInfo.display(listAcc);
				break;

			case 3 : 
				System.out.println("Enter Account number do you want to search in the record : ");
				int ano = sc.nextInt();
				Account temp = ainfo.searchAccount(listAcc, ano);
				if(temp!=null)
				{
					System.out.println("\nRecord found \n");
					System.out.println(temp.getAccNo() + "\t" + temp.getCustName() + "\t" + temp.getAccBal());

					System.out.println("Do you want to preformed transaction ? y/n ");
					String str = sc.next();


					int cho = 0;
					if(str.equals("y")) 
					{
						System.out.println("1 - Deposit\n2 - Withdraw");
						System.out.println("Enter your choice : ");
						cho=sc.nextInt();

						if(cho==1)
						{
							System.out.println("Enter amount to deposit :  ");
							double damt = sc.nextDouble();
							ainfo.deposit(temp, damt);
						}
						else if(cho==2)
						{
							System.out.println("Enter amount to withdraw : ");
							double amt = sc.nextDouble();
							ainfo.withdraw(temp, amt);
							break;
						}
						if(str.equals("n"))
						{
							System.out.println("Transaction completed");
						}
					}					
				}	
				else
				{
					System.out.println("\nRecord not found \n");
					break;
				}
			case 4 :
				// sorting command
				AccountInfo.display(listAcc);

				break;	

			case 5 :
				//updation of account 
				break;

			case 6 :
				System.out.println("Enter Account number : ");
				int accno = sc.nextInt();
				ainfo.removeAccount(listAcc, accno);
				break;

			default :
				System.out.println("Invalid choice ! ");
				break;

			}

			try {
				System.out.println("Do you want to continue? press 1 (Main menu)");
				ch = sc.nextInt();
			}
			catch(InputMismatchException ex2) {
				System.err.println("Exception is : " + ex2);
				System.out.println("Please Enter Integer values only...");
			}

		}
		while(ch == 1);
		System.out.println("Thank you..");		

	}
}
