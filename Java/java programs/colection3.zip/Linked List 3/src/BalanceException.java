
public class BalanceException extends Exception {

	public String toString() {
		return "Balance must be greater than 1000";
	}
}
