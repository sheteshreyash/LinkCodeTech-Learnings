import java.util.InputMismatchException;
import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;

public class AccountInfo {
	Scanner sc = new Scanner(System.in);

	public List<Account> createAccount() throws BalanceException {  // To create the account

		List<Account> list = new LinkedList<Account>();
		int ch = 0;

		do {
			System.out.println("Enter Account No, Customer Name and Account Balance : ");
			int accno = sc.nextInt();
			String accName = sc.next();
			double accBal = sc.nextDouble();

			list.add(new Account(accno, accName, accBal));

			try {
				if(accBal < 1000) {
					throw new BalanceException();
				}
			}
			catch(BalanceException b) {
				System.err.println("Exception : " + b);
				throw b;
			}

			try {
				System.out.println("Do you want to continue ? press 1 (Creating the account)");
				ch = sc.nextInt();
			}
			catch(InputMismatchException ex) {
				System.err.println("Exception is : " + ex);
				System.out.println("Please Enter Integer values only...");
			}
		}
		while(ch == 1);

		return list;
	}


	public static void display(List<Account> list) {  // To display account

		System.out.println("Account NO" + "\t" + "Cust Name" + "\t" + "Account Balance");
		System.out.println("\t");
		for(Account a : list) {

			System.out.println(a.getAccNo() + "\t\t" + a.getCustName() + "\t\t" + a.getAccBal());
		}		
	}


	public Account searchAccount(List<Account> list, int ano) {  // To search the account
		Account temp = null;

		for(Account a : list) {
			if(a.getAccNo() == ano) {
				temp = a;
				break;
			}	
		}
		return temp;			
	}


	public void deposit(Account temp, double damt) {  // to deposit the amount
		temp.setAccBal(temp.getAccBal()+ damt);
		System.out.println("Amount deposited !");
		System.out.println("New amount is " + temp.getAccBal());

	}


	public void withdraw(Account temp, double amt) {  // to withdraw the amount
		if(temp.getAccBal()> amt)
		{
			temp.setAccBal(temp.getAccBal() - amt);
			System.out.println("Amount can be withdrawn"); // to check whether the given amount is greater than the amount which is already present in the balance
		}
		else
		{
			System.out.println("Amount cannot be withdrawn ");
		}
		System.out.println("New amount is " + temp.getAccBal());
	}


	/*	public Account sortAccount(List<Account> list) {  // for sorting	(Wrong)
		int temp = 0;

		System.out.println("-------Sorting by Account balance--------");
		for(Account a : list) {
			for(Account b : list) {
				System.out.println(Collections.sort(a.getAccBal() <T> b.getAccBal()));
			}
		}
		return temp;



	}                                                                     */                                                                         


	public List<Account> UpdateAccount(int n, List<Account> list) {  // Update Account (wrong)

		System.out.println("Enter which Account do you want to update : ");
		n = sc.nextInt();
		list.set(0, null);

		return list;	
	}


	public Account removeAccount(List<Account> list, int accno) {  // to delete the account
		Account temp3 = searchAccount(list, accno);

		if(temp3 != null) {
			list.remove(temp3);			
		}
		else {
			System.out.println("Account not found !");
		}

		System.out.println("Entry deleted successfully !");

		return temp3;

	}
}
