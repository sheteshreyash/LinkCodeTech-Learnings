import java.util.List;
import java.util.LinkedList;
import java.util.Scanner;

public class Collection {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in); 	
		List<Integer> lst = new LinkedList<Integer>();  // dynamic binding..

		System.out.println("Enter first no in the linked list : ");   
		int n1 = sc.nextInt();
		lst.add(n1);    // command to add integers/values in the linked list

		System.out.println("Enter Second no in the linked list : ");
		int n2 = sc.nextInt();
		lst.add(n2);

		System.out.println("Enter third no in the linked list : ");
		int n3 = sc.nextInt();
		lst.add(n3);

		System.out.println("Enter 4th no in the linked list : ");
		int n4 = sc.nextInt();
		lst.add(n4);


		System.out.println("Linked list : " + lst);   // to print the linked list 
		System.out.println("Element present or not : " + lst.contains(n2));  // to check if the given element is present in the linked list or not
		System.out.println("Removed Element : " + lst.remove(0));  // To remove the integer from the linked list..
		System.out.println("Index of n3 is : " + lst.indexOf(n3));  // /to display the index of integer eg. 0, 1, 2 
		System.out.println("Removed index of n1 is : " + lst.lastIndexOf(n1));   // returns the last timed index of the repeated element 
		System.out.println("Size of the linked list : " + lst.size());  // To display the size of the linked list..	


	}
}
