import java.util.Scanner;
import java.util.List;
import java.util.LinkedList;


public class Collection2 {

	public static void main(String[] args) {  //To take the input values from user and display the highest element present in the given linked list..

		Scanner sc = new Scanner(System.in);
		List<Integer> lst2 = new LinkedList<Integer>();  //dynamic binding..(runtime polymorphism)
		int ch = 0;
		int max = 0;

		System.out.println("To Enter the elements in the linked list..");
		do {

			System.out.println("Enter the element : ");
			int n = sc.nextInt();			
			lst2.add(n);

			if(lst2.get(lst2.size() - 1) > max) {  // it will check the size of the input element, store it to the respective index and compare its index value to 'max'...
				max = lst2.get(lst2.size() - 1);    // this will display the 
			}

			System.out.println("Do you want to continue ? press 1");
			ch = sc.nextInt();

		}while(ch == 1);


		System.out.println("Linked list : " + lst2);
		System.out.println("The highest Element is : " + max);	
		System.out.println("Thank you...");
	}
}
