import java.util.Scanner;

public class Array {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("How many elements do you want ");
		int n = sc.nextInt(); //n=18
		int arr[] = new int[n];
		
		for(int i=0;i<arr.length;i++) {
			System.out.println("Enter elements do you want : ");
			arr[i] = sc.nextInt();
		}
		for(int i=0;i<arr.length;i++) {
			System.out.println(arr[i]);
		}
		// store addition of 18 elements at location 19 in array
		int sum =0;
		for(int i=0;i<(arr.length-4);i++) {
			sum = sum + arr[i];
		}
		
		System.out.println("Elements Stored at Location 15 is sum ");
		
		int temp;
		temp = sum;
		arr[15] = temp;
		System.out.println(arr[15]);
		
		System.out.println("Elements Stored at location 16 is average...");
		int avg = 0;
		avg = sum/14;
		System.out.println(avg);
		arr[16] = avg;
		
		//Element at location 18
		for(int i=0;i<(arr.length-4);i++) {
			for(int j=0;j<arr.length;j++) {
				System.out.println(arr[i]);
				System.out.println(arr[j]);
				
			}
		}
		
		System.out.println("Array after storing add and average..");
		for(int i=0;i<arr.length;i++) {
			System.out.println(arr[i]);
		}
	}
}
