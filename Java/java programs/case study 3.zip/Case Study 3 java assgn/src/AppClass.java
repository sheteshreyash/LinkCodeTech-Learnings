import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;

public class AppClass {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		int ch = 0;
		AppEngine engine = new AppEngine();
		List<Student> stu = new LinkedList<Student>();
		List<Course> cor = new LinkedList<Course>();

		do {
			System.out.println("\n1 - To Create Student info\n2 - To Display the details..");
			System.out.println("Enter your choice : ");
			ch = sc.nextInt();

			switch(ch) {
			
			case 1 :
				stu = engine.register();
				cor = engine.introduce();				
				break;
				
			case 2 :
				AppEngine.display(stu);
				AppEngine.display2(cor);			
				break;
				
			default :
				System.out.println("Invalid choice...");
				break;
			}

			System.out.println("Do you want to continue ? press 1");
			ch = sc.nextInt();

		}while(ch == 1);
		System.out.println("Thank you....");

	}
}
