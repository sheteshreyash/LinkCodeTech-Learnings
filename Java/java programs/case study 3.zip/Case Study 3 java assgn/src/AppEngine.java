import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;

public class AppEngine {
	Scanner sc = new Scanner(System.in);

	public List<Student> register() { // To create student information of single student

		List<Student> list2 = new LinkedList<Student>();
		int ch = 0;

		do {
			System.out.println("Enter Student ID, Student Name and Student DOB");
			int sid = sc.nextInt();
			String sname = sc.next();
			String sdob = sc.next();

			list2.add(new Student(sid, sname, sdob));
			
		}while(ch == 1);

		return list2;		
	}
	

	public List<Course> introduce() {   // To create course information of single course

		List<Course> list1 = new LinkedList<Course>();
		int ch = 0;

		do {
			System.out.print("Enter Course ID, Course Name, Course Duration, Course Fees");
			int cid = sc.nextInt();
			String cname = sc.next();
			String cdur = sc.next();
			double fees = sc.nextDouble();

			list1.add(new Course(cid, cname, cdur, fees));

		}while(ch == 1);

		return list1;
	}
	
	
	
	
	public static void display(List<Student> list2) {  // to display the student information
		
		System.out.println("Student ID" + "\t" + "Student Name" + "\t" + "Student DOB");
		System.out.println("\t");
		for(Student s : list2) {
			System.out.println(s.getStdid() + "\t\t" + s.getStdname() + "\t\t" + s.getStdob());
		}				
	}
	
	
	public static void display2(List<Course> list1) {   // to display the course infomation 
		
		System.out.println("\n");
		System.out.println("Course ID" + "\t" + "Course Name" + "\t" + "Course Duration" + "\t" + "Course Fees");
		System.out.println("\t");
		for(Course c : list1) {
			System.out.println(c.getCourseid() + "\t\t" + c.getCoursename() + "\t\t" + c.getCoursedur() + "\t\t" + c.getCoursefee());
		}	
	}
}
