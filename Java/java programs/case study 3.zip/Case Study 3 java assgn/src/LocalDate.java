import java.util.Collection;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;

public class LocalDate implements List<LocalDate>{

	private Date jdate;

	public LocalDate(Date jdate) {
		super();
		this.jdate = jdate;
	}

	
	public Date getJdate() {
		return jdate;
	}
	public void setJdate(Date jdate) {
		this.jdate = jdate;
	}


	@Override
	public int size() {
		// TODO Auto-generated method stub
		return 0;
	}


	@Override
	public boolean isEmpty() {
		// TODO Auto-generated method stub
		return false;
	}


	@Override
	public boolean contains(Object o) {
		// TODO Auto-generated method stub
		return false;
	}


	@Override
	public Iterator<LocalDate> iterator() {
		// TODO Auto-generated method stub
		return null;
	}


	@Override
	public Object[] toArray() {
		// TODO Auto-generated method stub
		return null;
	}


	@Override
	public <T> T[] toArray(T[] a) {
		// TODO Auto-generated method stub
		return null;
	}


	@Override
	public boolean add(LocalDate e) {
		// TODO Auto-generated method stub
		return false;
	}


	@Override
	public boolean remove(Object o) {
		// TODO Auto-generated method stub
		return false;
	}


	@Override
	public boolean containsAll(Collection<?> c) {
		// TODO Auto-generated method stub
		return false;
	}


	@Override
	public boolean addAll(Collection<? extends LocalDate> c) {
		// TODO Auto-generated method stub
		return false;
	}


	@Override
	public boolean addAll(int index, Collection<? extends LocalDate> c) {
		// TODO Auto-generated method stub
		return false;
	}


	@Override
	public boolean removeAll(Collection<?> c) {
		// TODO Auto-generated method stub
		return false;
	}


	@Override
	public boolean retainAll(Collection<?> c) {
		// TODO Auto-generated method stub
		return false;
	}


	@Override
	public void clear() {
		// TODO Auto-generated method stub
		
	}


	@Override
	public LocalDate get(int index) {
		// TODO Auto-generated method stub
		return null;
	}


	@Override
	public LocalDate set(int index, LocalDate element) {
		// TODO Auto-generated method stub
		return null;
	}


	@Override
	public void add(int index, LocalDate element) {
		// TODO Auto-generated method stub
		
	}


	@Override
	public LocalDate remove(int index) {
		// TODO Auto-generated method stub
		return null;
	}


	@Override
	public int indexOf(Object o) {
		// TODO Auto-generated method stub
		return 0;
	}


	@Override
	public int lastIndexOf(Object o) {
		// TODO Auto-generated method stub
		return 0;
	}


	@Override
	public ListIterator<LocalDate> listIterator() {
		// TODO Auto-generated method stub
		return null;
	}


	@Override
	public ListIterator<LocalDate> listIterator(int index) {
		// TODO Auto-generated method stub
		return null;
	}


	@Override
	public List<LocalDate> subList(int fromIndex, int toIndex) {
		// TODO Auto-generated method stub
		return null;
	}	
}
